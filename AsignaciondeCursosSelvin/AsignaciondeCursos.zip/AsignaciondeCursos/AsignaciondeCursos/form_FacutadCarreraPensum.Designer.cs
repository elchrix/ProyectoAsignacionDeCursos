﻿namespace AsignaciondeCursos
{
    partial class form_FacutadCarreraPensum
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label4 = new System.Windows.Forms.Label();
            this.txt_nombrefacultad = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.Btn_ingresarfacultad = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txt_idfacultad = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.cbo_idcarrera = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.Btn_ingresarpensum = new System.Windows.Forms.Button();
            this.txt_anio = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cbo_idfacultad = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_nombrecarrera = new System.Windows.Forms.TextBox();
            this.txt_ciclos = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.Btn_ingresarcarrera = new System.Windows.Forms.Button();
            this.txt_idcarrera = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(407, 34);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(120, 17);
            this.label4.TabIndex = 47;
            this.label4.Text = "Nombre Facultad:";
            // 
            // txt_nombrefacultad
            // 
            this.txt_nombrefacultad.Location = new System.Drawing.Point(363, 57);
            this.txt_nombrefacultad.Margin = new System.Windows.Forms.Padding(4);
            this.txt_nombrefacultad.Name = "txt_nombrefacultad";
            this.txt_nombrefacultad.Size = new System.Drawing.Size(212, 22);
            this.txt_nombrefacultad.TabIndex = 46;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(101, 59);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(59, 17);
            this.label8.TabIndex = 43;
            this.label8.Text = "Ingrese:";
            // 
            // Btn_ingresarfacultad
            // 
            this.Btn_ingresarfacultad.Location = new System.Drawing.Point(315, 98);
            this.Btn_ingresarfacultad.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Btn_ingresarfacultad.Name = "Btn_ingresarfacultad";
            this.Btn_ingresarfacultad.Size = new System.Drawing.Size(115, 34);
            this.Btn_ingresarfacultad.TabIndex = 41;
            this.Btn_ingresarfacultad.Text = "Ingresar";
            this.Btn_ingresarfacultad.UseVisualStyleBackColor = true;
            this.Btn_ingresarfacultad.Click += new System.EventHandler(this.Btn_Ingresar_Facultad);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(261, 34);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(85, 17);
            this.label13.TabIndex = 39;
            this.label13.Text = "Id. Facultad:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txt_nombrefacultad);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.Btn_ingresarfacultad);
            this.groupBox1.Controls.Add(this.txt_idfacultad);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Location = new System.Drawing.Point(36, 85);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Size = new System.Drawing.Size(775, 159);
            this.groupBox1.TabIndex = 39;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Facultad";
            // 
            // txt_idfacultad
            // 
            this.txt_idfacultad.Location = new System.Drawing.Point(245, 57);
            this.txt_idfacultad.Margin = new System.Windows.Forms.Padding(4);
            this.txt_idfacultad.Name = "txt_idfacultad";
            this.txt_idfacultad.Size = new System.Drawing.Size(100, 22);
            this.txt_idfacultad.TabIndex = 42;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.cbo_idcarrera);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.Btn_ingresarpensum);
            this.groupBox3.Controls.Add(this.txt_anio);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Location = new System.Drawing.Point(36, 412);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox3.Size = new System.Drawing.Size(775, 159);
            this.groupBox3.TabIndex = 40;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Pensum";
            // 
            // cbo_idcarrera
            // 
            this.cbo_idcarrera.FormattingEnabled = true;
            this.cbo_idcarrera.Location = new System.Drawing.Point(245, 59);
            this.cbo_idcarrera.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbo_idcarrera.Name = "cbo_idcarrera";
            this.cbo_idcarrera.Size = new System.Drawing.Size(100, 24);
            this.cbo_idcarrera.TabIndex = 39;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(101, 62);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(59, 17);
            this.label9.TabIndex = 26;
            this.label9.Text = "Ingrese:";
            // 
            // Btn_ingresarpensum
            // 
            this.Btn_ingresarpensum.Location = new System.Drawing.Point(315, 102);
            this.Btn_ingresarpensum.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Btn_ingresarpensum.Name = "Btn_ingresarpensum";
            this.Btn_ingresarpensum.Size = new System.Drawing.Size(115, 34);
            this.Btn_ingresarpensum.TabIndex = 23;
            this.Btn_ingresarpensum.Text = "Ingresar";
            this.Btn_ingresarpensum.UseVisualStyleBackColor = true;
            this.Btn_ingresarpensum.Click += new System.EventHandler(this.Btn_ingresarpensum_Click);
            // 
            // txt_anio
            // 
            this.txt_anio.Location = new System.Drawing.Point(355, 62);
            this.txt_anio.Margin = new System.Windows.Forms.Padding(4);
            this.txt_anio.Name = "txt_anio";
            this.txt_anio.Size = new System.Drawing.Size(220, 22);
            this.txt_anio.TabIndex = 25;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(412, 34);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(115, 17);
            this.label10.TabIndex = 22;
            this.label10.Text = "Año del Pensum:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(243, 34);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(79, 17);
            this.label11.TabIndex = 21;
            this.label11.Text = "Id. Carrera:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(332, 134);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 17);
            this.label3.TabIndex = 41;
            this.label3.Text = "Id. Carrera:";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(468, 209);
            this.button3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(115, 34);
            this.button3.TabIndex = 43;
            this.button3.Text = "Ingresar";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(348, 164);
            this.textBox4.Margin = new System.Windows.Forms.Padding(4);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 22);
            this.textBox4.TabIndex = 44;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(455, 162);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(100, 24);
            this.comboBox1.TabIndex = 50;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(557, 134);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(134, 17);
            this.label7.TabIndex = 49;
            this.label7.Text = "Nombre de Carrera:";
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(580, 164);
            this.textBox6.Margin = new System.Windows.Forms.Padding(4);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(100, 22);
            this.textBox6.TabIndex = 48;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(452, 134);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(85, 17);
            this.label5.TabIndex = 46;
            this.label5.Text = "Id. Facultad:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(255, 162);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 17);
            this.label1.TabIndex = 45;
            this.label1.Text = "Ingrese:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(709, 134);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 17);
            this.label2.TabIndex = 42;
            this.label2.Text = "Ciclos:";
            // 
            // cbo_idfacultad
            // 
            this.cbo_idfacultad.FormattingEnabled = true;
            this.cbo_idfacultad.Location = new System.Drawing.Point(301, 65);
            this.cbo_idfacultad.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbo_idfacultad.Name = "cbo_idfacultad";
            this.cbo_idfacultad.Size = new System.Drawing.Size(100, 24);
            this.cbo_idfacultad.TabIndex = 38;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(404, 37);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(134, 17);
            this.label6.TabIndex = 37;
            this.label6.Text = "Nombre de Carrera:";
            // 
            // txt_nombrecarrera
            // 
            this.txt_nombrecarrera.Location = new System.Drawing.Point(427, 66);
            this.txt_nombrecarrera.Margin = new System.Windows.Forms.Padding(4);
            this.txt_nombrecarrera.Name = "txt_nombrecarrera";
            this.txt_nombrecarrera.Size = new System.Drawing.Size(100, 22);
            this.txt_nombrecarrera.TabIndex = 36;
            // 
            // txt_ciclos
            // 
            this.txt_ciclos.Location = new System.Drawing.Point(559, 69);
            this.txt_ciclos.Margin = new System.Windows.Forms.Padding(4);
            this.txt_ciclos.Name = "txt_ciclos";
            this.txt_ciclos.Size = new System.Drawing.Size(100, 22);
            this.txt_ciclos.TabIndex = 35;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(299, 37);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(85, 17);
            this.label12.TabIndex = 34;
            this.label12.Text = "Id. Facultad:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(101, 65);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(59, 17);
            this.label14.TabIndex = 33;
            this.label14.Text = "Ingrese:";
            // 
            // Btn_ingresarcarrera
            // 
            this.Btn_ingresarcarrera.Location = new System.Drawing.Point(315, 112);
            this.Btn_ingresarcarrera.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Btn_ingresarcarrera.Name = "Btn_ingresarcarrera";
            this.Btn_ingresarcarrera.Size = new System.Drawing.Size(115, 34);
            this.Btn_ingresarcarrera.TabIndex = 31;
            this.Btn_ingresarcarrera.Text = "Ingresar";
            this.Btn_ingresarcarrera.UseVisualStyleBackColor = true;
            this.Btn_ingresarcarrera.Click += new System.EventHandler(this.Btn_ingresarcarrera_Click);
            // 
            // txt_idcarrera
            // 
            this.txt_idcarrera.Location = new System.Drawing.Point(195, 66);
            this.txt_idcarrera.Margin = new System.Windows.Forms.Padding(4);
            this.txt_idcarrera.Name = "txt_idcarrera";
            this.txt_idcarrera.Size = new System.Drawing.Size(100, 22);
            this.txt_idcarrera.TabIndex = 32;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(556, 37);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(49, 17);
            this.label15.TabIndex = 30;
            this.label15.Text = "Ciclos:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(179, 37);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(79, 17);
            this.label16.TabIndex = 29;
            this.label16.Text = "Id. Carrera:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cbo_idfacultad);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.txt_nombrecarrera);
            this.groupBox2.Controls.Add(this.txt_ciclos);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.Btn_ingresarcarrera);
            this.groupBox2.Controls.Add(this.txt_idcarrera);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Location = new System.Drawing.Point(36, 249);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Size = new System.Drawing.Size(775, 159);
            this.groupBox2.TabIndex = 51;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Carrera";
            // 
            // form_FacutadCarreraPensum
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(847, 633);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "form_FacutadCarreraPensum";
            this.Text = "form_FacutadCarreraPensum";
            this.Load += new System.EventHandler(this.form_FacutadCarreraPensum_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_nombrefacultad;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button Btn_ingresarfacultad;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txt_idfacultad;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button Btn_ingresarpensum;
        private System.Windows.Forms.TextBox txt_anio;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cbo_idfacultad;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txt_nombrecarrera;
        private System.Windows.Forms.TextBox txt_ciclos;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button Btn_ingresarcarrera;
        private System.Windows.Forms.TextBox txt_idcarrera;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox cbo_idcarrera;
    }
}